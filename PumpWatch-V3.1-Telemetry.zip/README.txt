PumpWatch V3.1 telemetry patch

Files:
  pumpwatch/src/server.js
  pumpwatch/src/store.js
  pumpwatch/src/telemetry.js (new)
  pumpwatch/test/telemetry.test.js (new)

Purpose:
- Persist timestamped market observations for discovered/watchlisted tokens.
- Track each token's first-seen price and first qualified signal.
- Measure post-signal peak/trough multiples and observed 15m, 1h, 6h, 24h returns.
- Keep bounded history and a bounded active tracking set.
- Expose GET /api/telemetry for summary and latest tracked tokens.

Important:
- This is telemetry only. It does not enable automatic paper trading or live trading.
- Scanner discovery must be enabled to discover and track new candidates. Keep autoPaper=false.
- Horizon returns are recorded at the first collected observation at or after the horizon, not at an exact candle boundary.
- DexScreener snapshots are observations, not historical OHLCV candles. This collector does not claim to provide candle-level backtests.

Installation from repository root:
  mkdir -p /tmp/pw31 && unzip -o PumpWatch-V3.1-Telemetry.zip -d /tmp/pw31
  cp /tmp/pw31/pumpwatch/src/. src/
  cp /tmp/pw31/pumpwatch/test/telemetry.test.js test/
  npm test

Back up src, test, and README before copying. Do not overwrite data/state.json or .env.
