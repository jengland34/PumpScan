import { getTokenMarket } from './market.js';
const DEX='https://api.dexscreener.com';
async function json(url){const r=await fetch(url,{headers:{accept:'application/json'},signal:AbortSignal.timeout(12000)});if(!r.ok)throw new Error(`Market provider returned ${r.status}`);return r.json()}
async function rugcheck(mint){try{const r=await fetch(`https://api.rugcheck.xyz/v1/tokens/${encodeURIComponent(mint)}/report/summary`,{headers:{accept:'application/json'},signal:AbortSignal.timeout(10000)});if(!r.ok)return {available:false};const d=await r.json();return {available:true,scoreNormalised:Number.isFinite(Number(d.score_normalised))?Number(d.score_normalised):null,score:Number(d.score),lpLockedPct:d.lpLockedPct==null?null:Number(d.lpLockedPct),risks:Array.isArray(d.risks)?d.risks.map(x=>({name:x.name,level:x.level,description:x.description})):[],mintAuthority:d.mintAuthority??null,freezeAuthority:d.freezeAuthority??null};}catch{return {available:false}}}
export async function discoverCandidates(limit=24){
 const [profiles,boosts]=await Promise.allSettled([json(`${DEX}/token-profiles/latest/v1`),json(`${DEX}/token-boosts/latest/v1`)]);
 const items=[...(profiles.status==='fulfilled'&&Array.isArray(profiles.value)?profiles.value:[]),...(boosts.status==='fulfilled'&&Array.isArray(boosts.value)?boosts.value:[])];
 const seen=new Set();const mints=items.filter(x=>x.chainId==='solana'&&x.tokenAddress&&!seen.has(x.tokenAddress)&&seen.add(x.tokenAddress)).slice(0,limit);
 const rows=[];
 for(const item of mints){try{const market=await getTokenMarket(item.tokenAddress);const pairAgeHours=market.pairCreatedAt?Math.max(0,(Date.now()-market.pairCreatedAt)/3600000):null;const report=await rugcheck(item.tokenAddress);const m=market.raw||{};const buys5m=Number(m.txns?.m5?.buys||0),sells5m=Number(m.txns?.m5?.sells||0),volume5m=Number(m.volume?.m5||0);const riskLevels=report.risks.map(x=>String(x.level||'').toLowerCase());const severe=riskLevels.some(x=>['danger','critical'].includes(x));const score=Number.isFinite(report.scoreNormalised)?report.scoreNormalised:null;
 const checks={liquidity:market.liquidityUsd>=20000,volume5m:volume5m>=5000,age:pairAgeHours!==null&&pairAgeHours<=72,momentum:buys5m>sells5m,security:report.available&&score!==null&&score<35&&!severe};
 const passed=Object.values(checks).every(Boolean);const points=Object.values(checks).filter(Boolean).length;rows.push({...market,volume5mUsd:volume5m,buys5m,sells5m,pairAgeHours,rugcheck:report,checks,score:points,passed,source:items.some(x=>x.tokenAddress===item.tokenAddress&&x.amount)?'Boosted/profile':'Profile',scannedAt:new Date().toISOString()});}catch{}}
 rows.sort((a,b)=>Number(b.passed)-Number(a.passed)||b.score-a.score||b.volume5mUsd-a.volume5mUsd);return rows;
}
