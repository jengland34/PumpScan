export const DEFAULT_RULES = Object.freeze({
  stakeGbp: 30,
  takeProfitMultiple: 2,
  firstExitFraction: 0.5,
  trailingStopPct: 0.20,
  hardStopPct: 0.25,
  maxOpenPositions: 3,
  dailyLossLimitGbp: 30
});

export function evaluatePosition(position, currentPrice, rules = DEFAULT_RULES) {
  if (!Number.isFinite(currentPrice) || currentPrice <= 0) return { action: 'hold', reason: 'Invalid price' };
  const peakPrice = Math.max(position.peakPrice || position.entryPrice, currentPrice);
  const updated = { ...position, peakPrice };

  if (position.remainingFraction <= 0) return { action: 'hold', position: updated, reason: 'Already closed' };
  if (currentPrice <= position.entryPrice * (1 - rules.hardStopPct)) {
    return { action: 'sell_all', fraction: position.remainingFraction, position: updated, reason: 'Hard stop-loss' };
  }
  if (!position.firstTargetHit && currentPrice >= position.entryPrice * rules.takeProfitMultiple) {
    return { action: 'sell_partial', fraction: Math.min(rules.firstExitFraction, position.remainingFraction), position: { ...updated, firstTargetHit: true }, reason: '2x take-profit' };
  }
  if (position.firstTargetHit && currentPrice <= peakPrice * (1 - rules.trailingStopPct)) {
    return { action: 'sell_all', fraction: position.remainingFraction, position: updated, reason: 'Trailing stop' };
  }
  return { action: 'hold', position: updated, reason: 'Monitoring' };
}
