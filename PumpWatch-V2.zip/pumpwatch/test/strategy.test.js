import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluatePosition, DEFAULT_RULES } from '../src/strategy.js';
const p={entryPrice:1,peakPrice:1,remainingFraction:1,firstTargetHit:false};
test('holds below first target',()=>assert.equal(evaluatePosition(p,1.5).action,'hold'));
test('sells half at 2x',()=>{const r=evaluatePosition(p,2);assert.equal(r.action,'sell_partial');assert.equal(r.fraction,0.5);assert.equal(r.position.firstTargetHit,true)});
test('hard stop exits before target',()=>assert.equal(evaluatePosition(p,0.74).action,'sell_all'));
test('trailing stop exits remaining half after target',()=>{const after={...p,firstTargetHit:true,remainingFraction:0.5,peakPrice:3};const r=evaluatePosition(after,2.39);assert.equal(r.action,'sell_all');assert.equal(r.reason,'Trailing stop')});
test('default stake is thirty pounds',()=>assert.equal(DEFAULT_RULES.stakeGbp,30));
