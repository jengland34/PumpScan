# PumpWatch V2 — phone-first Solana scanner & paper auto-trader

PumpWatch V2 is a mobile-first Progressive Web App (PWA). It discovers candidate Solana tokens from DexScreener's latest token-profile and latest-boost feeds, enriches them with DexScreener market data and RugCheck report summaries, ranks them against configurable filters, and can automatically open **simulated paper positions**. It also monitors paper positions and simulates scale-out exits.

## Safety boundary

**This release cannot trade real cryptocurrency.** It has no wallet integration, no private-key handling, no Jupiter execution and no live mode. `autoPaper` means simulated paper entries only. Do not add wallet seed phrases or private keys to this app.

## V2 features

- PWA interface designed for Android/mobile browsers; add it to the home screen after deployment.
- DexScreener latest token profile + latest boosted token discovery feeds (not a complete firehose of every new mint).
- Candidate enrichment using the most liquid pair returned by DexScreener.
- Filters: minimum liquidity ($20,000), 5-minute volume ($5,000), pair age (72h), positive 5-minute buy pressure, RugCheck normalized risk score (below 35) and no `danger`/`critical` risk level.
- Candidate ranking and manual paper-entry button.
- Optional automatic paper entries when the scanner is enabled and every filter passes.
- £30 maximum stake, maximum 3 open positions, 2x partial exit (50%), 20% trailing stop after first target, 25% hard stop, £30 daily realized-loss pause.
- Password protection using HTTP Basic Auth when `APP_PASSWORD` is configured.
- Persistent JSON state under `/app/data` (mount a persistent disk there when hosted).

## Scanner caveats

- DexScreener's profile and boost endpoints are curated/enhanced/paid-promotion feeds, not every new Solana token. A paid boost is not a quality signal.
- Holder-count and sellability simulation are not currently included. Do not interpret a RugCheck summary as a guarantee that a token is safe or sellable.
- The scanner requires a RugCheck summary to pass its security filter. If RugCheck is unavailable or does not return a normalized score, that candidate will fail the security filter.
- Public API availability, data freshness and rate limits can change. Discovery is intentionally throttled and runs about every 90 seconds while enabled.
- Pair age is derived from the selected DexScreener pair, which may not represent the token's first-ever liquidity pool.

## Run locally

Requires Node.js 20+.

```bash
cp .env.example .env
# Set APP_PASSWORD to a long unique password before exposing the app beyond localhost.
npm test
npm start
```

Open `http://localhost:3000`. To test from a phone on the same Wi-Fi, use the computer's LAN IP and port 3000. Do not expose a local unauthenticated instance to the public internet.

## Deploy to Render (recommended for phone access)

1. Push this folder to a private GitHub repository.
2. In Render, create a new Blueprint deployment and select the repository. Render reads `render.yaml`.
3. The Blueprint provisions a Docker web service, generated `APP_PASSWORD`, and a persistent disk mounted at `/app/data`. Use a paid always-on instance; a sleeping/free instance is unsuitable for continuous monitoring.
4. In the Render dashboard, reveal/copy the generated `APP_PASSWORD` from the service environment. Keep it private.
5. Open the HTTPS service URL on your Android phone and sign in. In Chrome, use **⋮ → Add to Home screen** (or **Install app**, if offered).
6. Keep the app's scanner enabled only when you want it running. The server must remain online for continuous scans and exits.

HTTP Basic Auth is deliberately simple for this personal prototype. Use a unique long password and keep the service private. For a multi-user/public product, replace it with proper user sessions, CSRF protection, stronger rate limiting and an audited auth design.

## Environment variables

- `PORT` — defaults to 3000.
- `APP_PASSWORD` — when set, protects the UI and API with HTTP Basic Auth. Set this on any public host.
- `POLL_INTERVAL_MS` — price monitoring interval; minimum 10 seconds, default 15 seconds.
- `GBP_USD` — estimated GBP/USD conversion for paper accounting; default 1.27. It is not a live FX feed.

## Tests

```bash
npm test
```

## Live execution is intentionally out of scope

A live trading phase would require a separate hot wallet with a strict capital cap, server-side managed signing (KMS/HSM or dedicated signer), transaction simulation, fresh route and minimum-output checks, idempotency, on-chain balance reconciliation, authentication hardening, audit logs, emergency stop, and extensive paper/devnet testing. Never store a wallet seed phrase in the browser, repository or ordinary `.env` file.
