const HORIZONS = Object.freeze({
  '5m': 5 * 60 * 1000,
  '15m': 15 * 60 * 1000,
  '30m': 30 * 60 * 1000,
  '60m': 60 * 60 * 1000,
  '6h': 6 * 60 * 60 * 1000,
  '24h': 24 * 60 * 60 * 1000
});

export const MAX_HISTORY_PER_TOKEN = 480;
export const MAX_TRACKED_TOKENS = 100;
export const TRACKED_REFRESH_PER_SCAN = 20;

export function createObservation(market, at = new Date().toISOString()) {
  return {
    at,
    priceUsd: Number(market.priceUsd) || 0,
    liquidityUsd: Number(market.liquidityUsd) || 0,
    volume5mUsd: Number(market.volume5mUsd) || 0,
    volume24hUsd: Number(market.volume24hUsd) || 0,
    buys5m: Number(market.buys5m) || 0,
    sells5m: Number(market.sells5m) || 0,
    priceChange5m: Number(market.priceChange5m) || 0,
    marketCapUsd: Number(market.marketCapUsd) || 0
  };
}

export function appendObservation(history = [], market, at = new Date().toISOString(), limit = MAX_HISTORY_PER_TOKEN) {
  const next = createObservation(market, at);
  const rows = Array.isArray(history) ? history : [];
  const last = rows[rows.length - 1];
  if (last?.at === at) return [...rows.slice(0, -1), next].slice(-limit);
  return [...rows, next].slice(-limit);
}

function recordHorizons(existing = {}, baselineAt, baselinePrice, at, price) {
  const results = { ...(existing || {}) };
  const elapsedMs = Date.parse(at) - Date.parse(baselineAt);
  if (!Number.isFinite(elapsedMs) || !Number.isFinite(baselinePrice) || baselinePrice <= 0) return results;
  for (const [label, durationMs] of Object.entries(HORIZONS)) {
    if (!results[label] && elapsedMs >= durationMs) {
      const multiple = price / baselinePrice;
      results[label] = {
        observedAt: at,
        elapsedMinutes: Math.round(elapsedMs / 60000),
        returnMultiple: multiple,
        returnPct: (multiple - 1) * 100
      };
    }
  }
  return results;
}

export function updateTokenTracker(existing, market, scored = null, at = new Date().toISOString()) {
  const price = Number(market.priceUsd);
  if (!Number.isFinite(price) || price <= 0) return existing || null;

  const tracker = existing ? structuredClone(existing) : {
    address: market.address,
    symbol: market.symbol || 'UNKNOWN',
    name: market.name || 'Unknown token',
    firstSeenAt: at,
    firstSeenPriceUsd: price,
    peakPriceUsd: price,
    troughPriceUsd: price,
    observations: 0,
    firstSignalAt: null,
    firstSignalPriceUsd: null,
    firstSignalModel: null,
    firstSignalScore: null,
    signalPeakPriceUsd: null,
    signalTroughPriceUsd: null,
    firstSeenHorizons: {},
    horizons: {}
  };

  tracker.firstSeenHorizons ||= {};
  tracker.horizons ||= {};
  tracker.symbol = market.symbol || tracker.symbol;
  tracker.name = market.name || tracker.name;
  tracker.lastSeenAt = at;
  tracker.lastPriceUsd = price;
  tracker.observations = (tracker.observations || 0) + 1;
  tracker.peakPriceUsd = Math.max(tracker.peakPriceUsd || price, price);
  tracker.troughPriceUsd = Math.min(tracker.troughPriceUsd || price, price);
  tracker.peakMultipleFromFirstSeen = tracker.peakPriceUsd / tracker.firstSeenPriceUsd;
  tracker.troughMultipleFromFirstSeen = tracker.troughPriceUsd / tracker.firstSeenPriceUsd;
  tracker.firstSeenHorizons = recordHorizons(tracker.firstSeenHorizons, tracker.firstSeenAt, tracker.firstSeenPriceUsd, at, price);

  if (scored) {
    const checks = scored.checks || {};
    tracker.lastEvaluation = {
      at,
      model: scored.model || 'unknown',
      score: Number(scored.score) || 0,
      minEntryScore: Number(scored.minEntryScore) || null,
      passed: !!scored.passed,
      safetyPassed: !!scored.safetyPassed,
      historyReady: !!scored.historyReady,
      checks: { ...checks },
      failedChecks: Object.entries(checks).filter(([, ok]) => !ok).map(([key]) => key),
      signals: { ...(scored.signals || {}) },
      metrics: { ...(scored.metrics || {}) }
    };
  }

  if (!tracker.firstSignalAt && scored?.passed) {
    tracker.firstSignalAt = at;
    tracker.firstSignalPriceUsd = price;
    tracker.firstSignalModel = scored.model || 'unknown';
    tracker.firstSignalScore = Number(scored.score) || 0;
    tracker.signalPeakPriceUsd = price;
    tracker.signalTroughPriceUsd = price;
  }

  if (tracker.firstSignalAt && tracker.firstSignalPriceUsd > 0) {
    tracker.signalPeakPriceUsd = Math.max(tracker.signalPeakPriceUsd || price, price);
    tracker.signalTroughPriceUsd = Math.min(tracker.signalTroughPriceUsd || price, price);
    tracker.signalPeakMultiple = tracker.signalPeakPriceUsd / tracker.firstSignalPriceUsd;
    tracker.signalTroughMultiple = tracker.signalTroughPriceUsd / tracker.firstSignalPriceUsd;
    tracker.horizons = recordHorizons(tracker.horizons, tracker.firstSignalAt, tracker.firstSignalPriceUsd, at, price);
  }

  return tracker;
}

export function trimTracking(trackers = {}, max = MAX_TRACKED_TOKENS) {
  const entries = Object.entries(trackers || {});
  if (entries.length <= max) return trackers;
  entries.sort((a, b) => Date.parse(b[1].lastSeenAt || b[1].firstSeenAt) - Date.parse(a[1].lastSeenAt || a[1].firstSeenAt));
  return Object.fromEntries(entries.slice(0, max));
}

export function scannerDiagnostics(candidates = [], config = {}) {
  const rows = Array.isArray(candidates) ? candidates : [];
  const failedChecks = {};
  const models = { new_launch: 0, established: 0, unknown: 0 };
  let passed = 0, safetyPassed = 0, historyReady = 0, scoreReady = 0;
  for (const row of rows) {
    const model = models[row.model] === undefined ? 'unknown' : row.model;
    models[model] = (models[model] || 0) + 1;
    if (row.passed) passed++;
    if (row.safetyPassed) safetyPassed++;
    if (row.historyReady) historyReady++;
    if (Number(row.score) >= Number(row.minEntryScore ?? config.minEntryScore ?? 55)) scoreReady++;
    for (const [key, ok] of Object.entries(row.checks || {})) if (!ok) failedChecks[key] = (failedChecks[key] || 0) + 1;
    if (row.error) failedChecks.providerError = (failedChecks.providerError || 0) + 1;
  }
  return {
    at: new Date().toISOString(),
    total: rows.length,
    passed,
    safetyPassed,
    historyReady,
    scoreReady,
    models,
    failedChecks,
    config: {
      minLiquidityUsd: config.minLiquidityUsd,
      minVolume5mUsd: config.minVolume5mUsd,
      maxPairAgeHours: config.maxPairAgeHours,
      maxRiskScore: config.maxRiskScore,
      minEntryScore: config.minEntryScore,
      newLaunchMaxAgeHours: config.newLaunchMaxAgeHours
    }
  };
}

export function telemetrySummary(trackers = {}) {
  const rows = Object.values(trackers || {});
  const signalled = rows.filter(row => row.firstSignalAt);
  const evaluated = rows.filter(row => row.lastEvaluation);
  const byModel = { new_launch: 0, established: 0, unknown: 0 };
  const failedChecks = {};
  for (const row of signalled) byModel[row.firstSignalModel] = (byModel[row.firstSignalModel] || 0) + 1;
  for (const row of evaluated) for (const key of row.lastEvaluation.failedChecks || []) failedChecks[key] = (failedChecks[key] || 0) + 1;
  const milestones = { '2x': 0, '3x': 0, '5x': 0, '10x': 0 };
  for (const row of signalled) {
    const peak = Number(row.signalPeakMultiple) || 0;
    for (const [label, multiple] of [['2x', 2], ['3x', 3], ['5x', 5], ['10x', 10]]) if (peak >= multiple) milestones[label]++;
  }
  return { trackedTokens: rows.length, evaluatedTokens: evaluated.length, qualifiedSignals: signalled.length, byModel, latestFailedChecks: failedChecks, peakMilestones: milestones };
}
